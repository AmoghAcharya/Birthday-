const giftBox = document.getElementById('giftBox');
const hearts = document.querySelectorAll('.heart');
let heartsClicked = 0;

giftBox.onclick = () => {
  document.getElementById('giftStage').classList.add('hidden');
  document.getElementById('heartStage').classList.remove('hidden');
};

hearts.forEach(heart => {
  heart.onclick = () => {
    if (!heart.classList.contains('clicked')) {
      heart.classList.add('clicked');
      heartsClicked++;
      if (heartsClicked === 4) {
        document.getElementById('heartStage').classList.add('hidden');
        document.getElementById('nameStage').classList.remove('hidden');
      }
    }
  };
});

function goToWishes() {
  const name = document.getElementById('nameInput').value;
  document.getElementById('nameDisplay').textContent = name;
  document.getElementById('finalName').textContent = name;
  document.getElementById('nameStage').classList.add('hidden');
  document.getElementById('wishStage').classList.remove('hidden');
}

function goToPhoto() {
  document.getElementById('wishStage').classList.add('hidden');
  document.getElementById('photoStage').classList.remove('hidden');
}
